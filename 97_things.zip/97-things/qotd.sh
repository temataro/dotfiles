#!/usr/bin/bash

files=( $HOME/dev/dotfiles/97-things/thing_*/README.md)
random_file="${files[($RANDOM) % ${#files[@]}]}"

echo "$RANDOM"
echo "97 Things Every Programmer Should Know: $random_file"

/usr/bin/glow --pager "$random_file"
